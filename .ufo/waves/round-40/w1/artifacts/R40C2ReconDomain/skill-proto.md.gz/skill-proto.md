# SKILL

## Queue-drain craft

Craft prose before the block.

<!-- sqfs-triage-table v2 -->

<!-- sqfs-triage-actions: check-superblock rerun-with-be reinstall-extractor compare-oracle expect-absent salvage-published none -->
| label | operation | provider | handler | gap kinds | dependencies | -be in child argv | symlink removed | published files | action | cause | source |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| no-squashfs-chunk | `extract_firmware` | `unblob` | `none` | `*` | `*` | `n/a` | `*` | `*` | `check-superblock` | cause prose for this row | knowledge entry :50-54 |
| dep-missing-be | `extract_firmware` | `unblob` | `squashfs_v4_be` | `missing-extractor-dependency` | `sasquatch-v4be` | `n/a` | `no` | `*` | `reinstall-extractor` | cause prose for this row | S112 lines 68-69; S120 command.py:101-102 |
| dep-missing-le | `extract_firmware` | `unblob` | `squashfs_v4_le` | `missing-extractor-dependency` | `sasquatch` | `n/a` | `no` | `*` | `reinstall-extractor` | cause prose for this row | S112; S120 command.py:101-102 |
| avm-marker-be-dropped | `extract_firmware` | `unblob` | `squashfs_v4_be` | `extractor-failure` | `none` | `no` | `no` | `0` | `rerun-with-be` | cause prose for this row | S112 lines 44-50; S121 |
| body-extractor-failure | `extract_firmware` | `unblob` | `squashfs_v4_be` | `extractor-failure` | `none` | `yes` | `no` | `0` | `compare-oracle` | cause prose for this row | S120 report.py:91-98 |
| partial-body-failure | `extract_firmware` | `unblob` | `squashfs_v4_*` | `extractor-failure` | `none` | `*` | `*` | `>0` | `salvage-published` | cause prose for this row | R39-CL3 D1 (round-39 verifier spot-check §5) |
| mixed-symlinks | `extract_firmware` | `unblob` | `squashfs_v4_*` | `unpublished-entry` | `none` | `n/a` | `yes` | `>0` | `expect-absent` | cause prose for this row | R39-CL2 |
| escaping-symlink-removed | `extract_firmware` | `unblob` | `squashfs_v4_*` | `*` | `*` | `n/a` | `yes` | `>0` | `expect-absent` | cause prose for this row | S118 extractor.py:79-91 |
| in-tree-symlink-metadata | `extract_firmware` | `unblob` | `squashfs_v4_*` | `unpublished-entry` | `none` | `n/a` | `no` | `>0` | `expect-absent` | cause prose for this row | S119 FirmwarePublication.js:68-75,301-308 |
| clean-empty | `extract_firmware` | `unblob` | `squashfs_v4_*` | `none` | `none` | `n/a` | `no` | `0` | `none` | cause prose for this row | R39-CL3 D2 |
| clean | `extract_firmware` | `unblob` | `squashfs_v4_*` | `none` | `none` | `n/a` | `no` | `>0` | `compare-oracle` | cause prose for this row | S119; knowledge entry :11-19 |

## A later section

Prose after the craft section.
