#!/usr/bin/env python3
"""Bounded text-only outer-CLI mutation probe; never imports either reader."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys

ROOT = Path('/fast/scratch/hyaku/kaidoku-r34/w1/MutCounterTypes')
BASE = ROOT / '.ufo/waves/round-34/mut-counter-types'
ACTIVE = BASE / 'active'
RECEIPTS = BASE / 'receipts'
FREEZE = '54a87a51a865ab931fd355e767303337b05cccf4'
COUNTER = ROOT / 'tools/round-34/version-needs-counter.py'
CLAIMS = ROOT / '.ufo/waves/round-34/claims.json'
MANIFEST = ROOT / '.ufo/waves/round-34/expected.json'
PREDICATE = 'P34-version-needs: twelve public ELF carriers yield exactly their independently frozen GNU version-needs records on opaque paths, including randomized same-length string-table naming wherever requirements are present, and the pinned source-backed decision table is present.'
MAX_WRITE = 2 * 1024 * 1024
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
resource.setrlimit(resource.RLIMIT_FSIZE, (4 * 1024 * 1024, 4 * 1024 * 1024))
resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def put(path, data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    if len(data) > MAX_WRITE:
        raise ValueError('bounded_fixture_write_exceeded')
    if not path.is_relative_to(BASE):
        raise ValueError('outside_sandbox_probe_directory')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

def packed(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=True)

def reader(text, suffix=''):
    return ('print(' + repr(text) + ')\n' + suffix).encode()

TEXT = b'benign text fixture only\n'
EXPECTED = {'schema': 1, 'needed': [
    {'file': 'libA', 'versions': [
        {'name': 'VER_1', 'flags': 0, 'other': 1, 'hash': 1},
        {'name': 'VER_2', 'flags': 0, 'other': 2, 'hash': 2}]},
    {'file': 'libB', 'versions': [
        {'name': 'VER_B', 'flags': 0, 'other': 3, 'hash': 3}]}]}
SPEC_VALUE = {'target': 1, 'documents_ok': True, 'manifest': {'schema': 1, 'carriers': [
    {'id': 'text-only', 'path': 'input.txt', 'size': len(TEXT),
     'sha256': sha(TEXT), 'expected': EXPECTED}]}}
SPEC = (packed(SPEC_VALUE) + '\n').encode()
OUTPUT = packed(EXPECTED)
READER = reader(OUTPUT)
BASELINE = {'input.txt': TEXT, 'spec.json': SPEC, 'reader.py': READER}
CASES = []

def add(name, axis, changed, expected_exit, expected_finding, rationale, positive=False):
    if len(changed) != 1:
        raise ValueError('one_behavior_bearing_file_per_mutation')
    CASES.append({'name': name, 'axis': axis, 'changed': changed,
                  'expected_exit': expected_exit, 'expected_finding': expected_finding,
                  'rationale': rationale, 'positive_control': positive})

def output_case(name, axis, text, rationale, positive=False, suffix=''):
    add(name, axis, {'reader.py': reader(text, suffix)}, 0 if positive else 1,
        'version_needs_match' if positive else 'version_needs_mismatch', rationale, positive)

def value_case(name, field, value):
    changed = copy.deepcopy(EXPECTED)
    if field == 'schema':
        changed['schema'] = value
    else:
        changed['needed'][0]['versions'][0][field] = value
    output_case(name, 'bool-vs-int', packed(changed), 'Only output ' + field + ' changes JSON type without changing its Python numeric equality.')

for name, text in [
    ('duplicate-schema-equal', OUTPUT.replace('"schema":1', '"schema":1,"schema":1', 1)),
    ('duplicate-schema-last-good', OUTPUT.replace('"schema":1', '"schema":2,"schema":1', 1)),
    ('duplicate-needed-last-good', OUTPUT.replace('"needed":', '"needed":[],"needed":', 1)),
    ('duplicate-file-last-good', OUTPUT.replace('"file":"libA"', '"file":"WRONG","file":"libA"', 1)),
    ('duplicate-versions-last-good', OUTPUT.replace('"versions":', '"versions":[],"versions":', 1)),
    ('duplicate-hash-last-good', OUTPUT.replace('"hash":1', '"hash":0,"hash":1', 1)),
]:
    output_case(name, 'duplicate-json-keys', text, 'A duplicate JSON key must not be silently resolved by last-key-wins.')

for field, value in [('schema', True), ('flags', False), ('other', True), ('hash', True)]:
    value_case('output-' + field + '-boolean', field, value)
for field, value in [('schema', 1.0), ('flags', 0.0), ('other', 1.0), ('hash', 1.0)]:
    value_case('output-' + field + '-float', field, value)

changed = copy.deepcopy(EXPECTED)
changed['needed'].reverse()
output_case('needed-reversed', 'row-order-duplicates', packed(changed), 'Needed files are canonical lexicographic order, not arbitrary order.')
changed = copy.deepcopy(EXPECTED)
changed['needed'][0]['versions'].reverse()
output_case('versions-reversed', 'row-order-duplicates', packed(changed), 'Versions are canonical (name, other) order, not arbitrary order.')
changed = copy.deepcopy(EXPECTED)
changed['needed'].insert(1, copy.deepcopy(changed['needed'][0]))
output_case('needed-exact-duplicate', 'row-order-duplicates', packed(changed), 'A repeated needed row must not collapse through set comparison.')
changed = copy.deepcopy(EXPECTED)
changed['needed'][1]['file'] = 'libA'
output_case('needed-duplicate-file', 'row-order-duplicates', packed(changed), 'Different needed rows sharing a file key are not unique.')
changed = copy.deepcopy(EXPECTED)
changed['needed'][0]['versions'].insert(1, copy.deepcopy(changed['needed'][0]['versions'][0]))
output_case('version-exact-duplicate', 'row-order-duplicates', packed(changed), 'A repeated version row must not collapse through set comparison.')
changed = copy.deepcopy(EXPECTED)
extra = copy.deepcopy(changed['needed'][0]['versions'][0])
extra['hash'] = 42
changed['needed'][0]['versions'].insert(1, extra)
output_case('version-duplicate-name-other', 'row-order-duplicates', packed(changed), 'Uniqueness is (name, other), not whole-row identity.')
changed = {'needed': [{'versions': [dict(reversed(list(v.items()))) for v in row['versions']], 'file': row['file']} for row in EXPECTED['needed']], 'schema': 1}
output_case('object-key-order-positive', 'row-order-duplicates', packed(changed), 'JSON object member ordering is immaterial; arrays remain canonical.', positive=True)

for code in (1, 2, 7, 255):
    output_case('reader-nonzero-' + str(code), 'reader-exit', OUTPUT, 'Valid exact JSON followed by nonzero exit must not count.', suffix='raise SystemExit(' + str(code) + ')\n')
output_case('reader-stderr-positive', 'reader-exit', OUTPUT, 'Stderr text is not a nonzero exit and does not alter the exact stdout record.', positive=True, suffix='import sys\nprint("TEXT_PROBE_STDERR", file=sys.stderr)\n')

for name, replacement, finding in [
    ('spec-duplicate-target-last-good', SPEC.replace(b'"target":1', b'"target":0,"target":1', 1), 'duplicate_json_key:target'),
    ('spec-duplicate-manifest-schema', SPEC.replace(b'"manifest":{"schema":1', b'"manifest":{"schema":2,"schema":1', 1), 'duplicate_json_key:schema'),
    ('spec-duplicate-expected-hash', SPEC.replace(b'"hash":1', b'"hash":0,"hash":1', 1), 'duplicate_json_key:hash'),
]:
    add(name, 'duplicate-json-keys', {'spec.json': replacement}, 2, finding, 'Outer fixture JSON uses the same duplicate-key decoder.')

for name, mutate, finding in [
    ('spec-expected-schema-boolean', lambda s: s['manifest']['carriers'][0]['expected'].__setitem__('schema', True), 'manifest_row_schema'),
    ('spec-size-boolean', lambda s: s['manifest']['carriers'][0].__setitem__('size', True), 'manifest_row_schema'),
    ('spec-manifest-schema-boolean', lambda s: s['manifest'].__setitem__('schema', True), 'manifest_schema'),
    ('spec-manifest-schema-float', lambda s: s['manifest'].__setitem__('schema', 1.0), 'manifest_schema'),
    ('spec-target-boolean', lambda s: s.__setitem__('target', True), 'fixture_type_rejection'),
    ('spec-target-float', lambda s: s.__setitem__('target', 1.0), 'fixture_type_rejection'),
    ('spec-documents-integer', lambda s: s.__setitem__('documents_ok', 1), 'fixture_type_rejection'),
    ('spec-documents-string-false', lambda s: s.__setitem__('documents_ok', 'false'), 'fixture_type_rejection'),
]:
    changed = copy.deepcopy(SPEC_VALUE)
    mutate(changed)
    add(name, 'bool-vs-int', {'spec.json': (packed(changed) + '\n').encode()}, 2, finding,
        'Strict-type challenge to the isolated fixture envelope; no production contract or pinned manifest is changed. No particular diagnostic is required for a rejection.')

ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_') and not k.startswith('PYTHON')}
ENV['GIT_CONFIG_NOSYSTEM'] = '1'
ENV['GIT_CONFIG_GLOBAL'] = os.devnull
ENV['LC_ALL'] = 'C'
ARGV = ['/usr/bin/timeout', '--signal=TERM', '--kill-after=1s', '5s', '/usr/bin/python3', '-I', '-B', str(COUNTER),
        '--root', str(ROOT), '--rev', FREEZE, '--freeze', FREEZE,
        '--fixture-spec', str(ACTIVE / 'spec.json'), '--fixture-reader', str(ACTIVE / 'reader.py')]
ACTIVE_PROCESS = None

def interrupted(signum, frame):
    raise InterruptedError('probe_signal:' + str(signum))

signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)

def kill_active():
    global ACTIVE_PROCESS
    if ACTIVE_PROCESS is not None:
        try:
            os.killpg(ACTIVE_PROCESS.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        ACTIVE_PROCESS.wait(timeout=2)
        ACTIVE_PROCESS = None

def hashes():
    return {name: sha((ACTIVE / name).read_bytes()) for name in BASELINE}

def restore():
    for name, content in BASELINE.items():
        put(ACTIVE / name, content)

def detector(case, phase):
    global ACTIVE_PROCESS
    receipt = RECEIPTS / case / phase
    before_hashes = hashes()
    for name in BASELINE:
        put(receipt / name, (ACTIVE / name).read_bytes())
    started = utc()
    ACTIVE_PROCESS = subprocess.Popen(ARGV, cwd=ROOT, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    bounded_timeout = False
    try:
        stdout, stderr = ACTIVE_PROCESS.communicate(timeout=8)
        code = ACTIVE_PROCESS.returncode
        ACTIVE_PROCESS = None
    except subprocess.TimeoutExpired:
        bounded_timeout = True
        process = ACTIVE_PROCESS
        kill_active()
        stdout, stderr = process.communicate(timeout=2)
        code = process.returncode
    finally:
        kill_active()
    ended = utc()
    put(receipt / 'stdout.txt', stdout)
    put(receipt / 'stderr.txt', stderr)
    try:
        observed = json.loads(stdout)
    except (ValueError, UnicodeError):
        observed = None
    result = {'case': case, 'phase': phase, 'utc_start': started, 'utc_end': ended,
              'argv': ARGV, 'cwd': str(ROOT), 'exit': code, 'bounded_timeout': bounded_timeout,
              'stdout': stdout.decode('utf-8', errors='replace'), 'stderr': stderr.decode('utf-8', errors='replace'),
              'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr),
              'fixture_hashes_before': before_hashes, 'fixture_hashes_after': hashes(),
              'observed': observed, 'receipt': str(receipt.relative_to(BASE))}
    put(receipt / 'run.json', json.dumps(result, indent=2) + '\n')
    return result

def baseline_green(run):
    observed = run['observed'] or {}
    return run['exit'] == 0 and observed.get('met_target') is True and observed.get('matched') == 1 and observed.get('finding') == 'version_needs_match'

source_bytes = {str(path.relative_to(ROOT)): path.read_bytes() for path in (COUNTER, CLAIMS, MANIFEST)}
source_before = {path: sha(data) for path, data in source_bytes.items()}
put(BASE / 'frozen-counter.py', source_bytes[str(COUNTER.relative_to(ROOT))])
put(BASE / 'frozen-claims.json', source_bytes[str(CLAIMS.relative_to(ROOT))])
put(BASE / 'expected-baseline.json', packed(EXPECTED) + '\n')
measurement_start = utc()
rev = subprocess.run(['git', '--no-replace-objects', '-c', 'core.fsmonitor=false', '-C', str(ROOT), 'rev-parse', '--verify', 'HEAD^{commit}'], env=ENV, capture_output=True, timeout=5)
put(BASE / 'revision-run.json', json.dumps({'utc': utc(), 'argv': rev.args, 'exit': rev.returncode, 'stdout': rev.stdout.decode(), 'stderr': rev.stderr.decode()}, indent=2) + '\n')
if rev.returncode or rev.stdout.decode().strip() != FREEZE:
    raise ValueError('unexpected_sandbox_revision')
if source_before[str(COUNTER.relative_to(ROOT))] != 'd7f0a8cf3ca08562437d40711d15e7ad4f6fa44edb4e8934c36f4673e4e7c45e':
    raise ValueError('unexpected_frozen_counter_digest')

records = []
error = None
restore()
try:
    for case in CASES:
        restore()
        pristine = detector(case['name'], 'pristine')
        try:
            for name, data in case['changed'].items():
                put(ACTIVE / name, data)
            mutated = detector(case['name'], 'mutated')
        finally:
            restore()
        restored = detector(case['name'], 'restored')
        observed = mutated['observed'] or {}
        accepted = mutated['exit'] == 0 and bool(observed.get('met_target'))
        if not baseline_green(pristine) or not baseline_green(restored):
            verdict = 'inconclusive-baseline'
        elif case['positive_control']:
            verdict = 'positive-control-pass' if accepted else 'positive-control-fail'
        elif accepted:
            verdict = 'survived'
        elif mutated['bounded_timeout'] or mutated['exit'] not in (1, 2):
            verdict = 'inconclusive-detector'
        else:
            verdict = 'killed'
        record = {k: v for k, v in case.items() if k != 'changed'}
        record.update({'verdict': verdict, 'accepted': accepted,
                       'pristine_exit': pristine['exit'], 'mutated_exit': mutated['exit'], 'restored_exit': restored['exit'],
                       'pristine_green': baseline_green(pristine), 'restored_green': baseline_green(restored),
                       'finding': observed.get('finding'), 'matched': observed.get('matched'),
                       'met_target': observed.get('met_target'),
                       'changed_file': next(iter(case['changed'])),
                       'pristine_hashes': pristine['fixture_hashes_before'],
                       'mutated_hashes': mutated['fixture_hashes_before'],
                       'restored_hashes': restored['fixture_hashes_before'],
                       'restored_exact_bytes': all((ACTIVE / name).read_bytes() == data for name, data in BASELINE.items()),
                       'receipts': [pristine['receipt'], mutated['receipt'], restored['receipt']]})
        records.append(record)
        print(json.dumps({'case': case['name'], 'verdict': verdict, 'exits': [pristine['exit'], mutated['exit'], restored['exit']], 'finding': observed.get('finding'), 'matched': observed.get('matched'), 'met_target': observed.get('met_target')}, sort_keys=True), flush=True)
except BaseException as exc:
    error = repr(exc)
    raise
finally:
    kill_active()
    restore()
    source_after = {path: sha((ROOT / path).read_bytes()) for path in source_before}
    counts = {verdict: sum(row['verdict'] == verdict for row in records) for verdict in sorted({row['verdict'] for row in records})}
    result = {'assignment': 'MutCounterTypes', 'model_visible': 'openai-codex/gpt-6.1-sol',
              'axes': ['duplicate JSON keys', 'bool-vs-int and scalar types', 'row order and row uniqueness', 'reader exit status'],
              'predicate_verbatim': PREDICATE, 'mode': 'fixture-only; not production P34 score',
              'utc_start': measurement_start, 'utc_end': utc(), 'measured_revision': rev.stdout.decode().strip(),
              'freeze_revision': FREEZE, 'source_hashes_before': source_before, 'source_hashes_after': source_after,
              'source_exact_bytes_unchanged': all((ROOT / path).read_bytes() == data for path, data in source_bytes.items()),
              'baseline_fixture_hashes': {name: sha(data) for name, data in BASELINE.items()},
              'active_fixture_hashes_final': hashes(), 'active_fixture_exact_bytes_restored': all((ACTIVE / name).read_bytes() == data for name, data in BASELINE.items()),
              'case_count': len(CASES), 'completed_cases': len(records), 'detector_runs': 3 * len(records),
              'process_bounds': 'One child tree at a time: driver -> timeout -> frozen counter -> one fake TEXT reader. 5s timeout + 1s kill grace per detector, 8s communication cap. No background jobs.',
              'memory_limit_bytes': 512 * 1024 * 1024, 'individual_write_limit_bytes': MAX_WRITE,
              'tools_installed_or_updated': [], 'counts': counts, 'error': error, 'cases': records}
    put(BASE / 'summary.json', json.dumps(result, indent=2) + '\n')
    print(json.dumps({'summary': str(BASE / 'summary.json'), 'counts': counts, 'completed_cases': len(records), 'restored': result['active_fixture_exact_bytes_restored'], 'sources_unchanged': result['source_exact_bytes_unchanged'], 'error': error}, sort_keys=True), flush=True)
