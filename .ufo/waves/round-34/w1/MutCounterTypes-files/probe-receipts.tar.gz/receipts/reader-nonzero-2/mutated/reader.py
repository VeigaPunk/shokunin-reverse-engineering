print('{"schema":1,"needed":[{"file":"libA","versions":[{"name":"VER_1","flags":0,"other":1,"hash":1},{"name":"VER_2","flags":0,"other":2,"hash":2}]},{"file":"libB","versions":[{"name":"VER_B","flags":0,"other":3,"hash":3}]}]}')
raise SystemExit(2)
